import AuthForm from "@/components/auth/auth-form"

export default function Page() {
  return <AuthForm mode="signup" />
}
